AURA Stage B — GUARD-RS-001 log capture

Contents: complete text response returned by the connected GitHub job-log fetch action, encoded as UTF-8; capture-record.json; identity-lineage.json; payload-manifest.json.

IMPORTANT LIMITATION:
The GitHub connector returns decoded text, not the original compressed job-log HTTP response bytes. The log hash therefore binds the exact UTF-8 encoding of the returned text (including its leading BOM and returned line-ending form), not the original GitHub compressed log archive. No byte-for-byte identity with the original compressed download is claimed.

D-3 artifact reference: artifact ID 12512947814, name d3-real-chain-rust-output, ZIP SHA-256 024988956db987c883ce7071b6d2a2ac3de095f1e7a293ef3cddb8a2d1efb261. It is linked in the external manifest but is not duplicated inside this ZIP; the package build deliberately failed closed rather than using a manually copied Base64 representation that did not reproduce the validated artifact bytes.

Classification: technical evidence capture; non-normative; not a formal approval.
Review status: GOVERNANCE_REVIEW_PENDING. PR #13 remains Draft. No merge/release authority is implied.
