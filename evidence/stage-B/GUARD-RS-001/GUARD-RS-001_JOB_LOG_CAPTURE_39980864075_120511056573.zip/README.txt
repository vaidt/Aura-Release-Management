AURA Stage B — GUARD-RS-001 log capture

This ZIP contains the complete decoded job-log text returned by the connected GitHub log-fetch action, re-encoded as UTF-8, plus capture record, identity-lineage note, and payload manifest.

IMPORTANT LIMITATION: the GitHub integration returned decoded text, not the original compressed GitHub log HTTP response bytes. The recorded SHA-256 binds the exact UTF-8 serialization, including BOM and received line endings, not the original compressed archive.

D-3 artifact reference: ID 12512947814, name d3-real-chain-rust-output, ZIP SHA-256 024988956db987c883ce7071b6d2a2ac3de095f1e7a293ef3cddb8a2d1efb261. It is referenced by the external manifest, not embedded in this ZIP. A manually transferred Base64 representation failed hash validation and was rejected.

Classification: non-normative technical evidence; not a formal acceptance decision.
